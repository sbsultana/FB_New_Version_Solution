import {
  Component,
  OnInit,
  ViewChild,
  TemplateRef,
  ChangeDetectorRef,
  HostListener,
  Directive
} from '@angular/core';
import { BsDatepickerConfig, BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { DatePipe, CommonModule } from '@angular/common';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { SharedModule } from '../../../../Core/Providers/Shared/shared.module';
import { Sharedservice } from '../../../../Core/Providers/Shared/sharedservice';
import { Setdates } from '../../../../Core/Providers/SetDates/setdates';
import { common } from '../../../../common';

import { HttpClient } from '@angular/common/http';


@Component({
  selector: 'app-dashboard',
  imports: [CommonModule, SharedModule, BsDatepickerModule,],
  templateUrl: './dashboard.html',
  styleUrl: './dashboard.scss'
})
export class Dashboard implements OnInit {
  @ViewChild('detailModal') detailModal!: TemplateRef<any>;
  item: any;
  activePopover: number = -1;
  @HostListener('document:click', ['$event'])
  clickOutside(event: MouseEvent) {
    const target = event.target as HTMLElement;

    if (!target.closest('.filter-dropdowns')) {
      this.activePopover = -1;
    }
  }

  DateType: any;
  maxToMonth!: Date;
  minToMonth!: Date;
  storeIds: any[] = [];
  stores: any[] = [];
  groupsArray: any[] = [];
  groups: any[] = [];
  groupName = '';
  storeName = '';
  storesList: any[] = [];
  allStoresData: any[] = [];
  selectedVars: any = { var1: 'All' };
  isPopoverOpen = false;
  storeButtonLabel: string = 'All';
  FromDate!: string;
  ToDate!: string;
  tomonth: Date | null = null;
  previous: Date = new Date();
  previousmultiplemax: Date = new Date();
  toprevious: any;
  fromDate: any;
  toDate: any;
  filteredMonths: string[] = [];
  constructor(public shared: Sharedservice,
    public setdates: Setdates,
    private comm: common,
    private cdr: ChangeDetectorRef,
    private datepipe: DatePipe,
    private modalService: NgbModal,
    private http: HttpClient

  ) {
    this.shared.setTitle(this.shared.common.titleName + '-Enterprise Tracking');
    if (typeof window !== 'undefined') {
      if (localStorage.getItem('UserDetails') != null) {
        // this.storeIds = 1
        //   this.shared.common.redirectionFrom.flag == 'M'
        //     ? JSON.parse(localStorage.getItem('UserDetails')!).Store_Ids
        //     : this.shared.common.redirectionFrom.store;
        // this.shared.common.redirectionFrom = { flag: 'M' };
        // this.groups= JSON.parse(localStorage.getItem('UserDetails')!).flag.groupid
      }

      if (localStorage.getItem('UserDetails') != null) {
        // this.setDates(this.DateType)
        // if (this.comm.groupsandstores != undefined && this.comm.groupsandstores.length > 0) {
        //   this.groupsArray = this.comm.groupsandstores;
        //   this.groupId = JSON.parse(localStorage.getItem('UserDetails')!).flag.groupid
        //   this.stores = this.comm.groupsandstores.filter((v: any) => v.sg_id == this.groupId)[0].Stores;
        //   if (this.storeIds == undefined || this.storeIds.length == 0) {
        // this.getStoresandGroupsValues()
        //   }
        // }
      }
      this.shared.setTitle(this.shared.common.titleName + '-AccountMapping');
      if (localStorage.getItem('Fav') != 'Y') {
        const data = {
          title: 'Account Mapping',

          stores: this.storeIds,

          datetype: 'MTD',
          fromdate: this.FromDate,
          todate: this.ToDate,

        };
        this.shared.api.SetHeaderData({
          obj: data,
        });
      }
    }
  }
  getMonthYear(): string {
    if (!this.frommonth) return '';

    const dateObj = this.frommonth instanceof Date ? this.frommonth : new Date(this.frommonth);
    const month = (dateObj.getMonth() + 1).toString().padStart(2, '0');
    const year = dateObj.getFullYear();

    return `${month}-${year}`;
  }

  togglePopover(popoverId: number) {
    this.activePopover = this.activePopover === popoverId ? -1 : popoverId;
  }
  ngOnInit(): void {
    this.shared.setTitle('Account Mapping');
    this.getStoresList();

    const today = new Date();
    const fromMonth = new Date(today.getFullYear(), today.getMonth(), 1);
    const toMonth = new Date(today.getFullYear(), today.getMonth() + 1, 0);

    this.frommonth = fromMonth;
    this.tomonth = toMonth;

    this.minToMonth = this.frommonth;
    this.maxToMonth = today;
    this.getGLAccountsInfo();

  }
  onApply(): void {
    this.applyFilters();

  }
  getStoresList(): void {
    this.shared.spinner.show();
    const obj = {
      "userid": 1
    }
    this.shared.api.postmethod('Tropical/GetStoresList', obj).subscribe({
      next: (res: any) => {
        console.log(res)
        if (res) {
          this.stores = res.response;
          this.storeIds = this.stores.map(s => s.ID);

          this.onApply();
          this.shared.spinner.hide();
        }
      },
      error: (err) => {
        this.shared.spinner.hide();
        console.error('Error fetching stores:', err);
      }
    });
  }
  toggleSelectAll() {
    if (this.storeIds.length === this.stores.length) {

      this.storeIds = [];
    } else {

      this.storeIds = this.stores.map(s => s.ID);
    }
    this.updateStoreSelection();
  }
  onStoreToggle(storeId: number) {
    const idx = this.storeIds.indexOf(storeId);
    if (idx >= 0) this.storeIds.splice(idx, 1);
    else this.storeIds.push(storeId);

    this.updateStoreSelection();
  }
  selectAllStores(): void {
    this.storeIds = this.stores.map(s => s.ID);
    this.updateStoreButtonLabel();
  }
  updateStoreButtonLabel(): void {
    if (this.storeIds.length === this.stores.length) {
      this.storeButtonLabel = 'All';
    } else if (this.storeIds.length === 1) {
      const selected = this.stores.find(s => s.ID === this.storeIds[0]);
      this.storeButtonLabel = selected?.storename || '';
    } else {
      this.storeButtonLabel = this.storeIds.length.toString();
    }
  }
  allstores(state: 'Y' | 'N') {
    this.storeIds = state === 'Y' ? this.stores.map(s => s.ID) : [];
    this.updateStoreSelection();
  }
  updateStoreSelection() {
    if (this.storeIds.length === this.stores.length) {
      this.storeButtonLabel = 'All';
      this.selectedVars.var1 = 'All';
    } else if (this.storeIds.length === 1) {
      const selected = this.stores.find(s => s.ID === this.storeIds[0]);
      this.storeButtonLabel = selected?.storename || '';
      this.selectedVars.var1 = selected?.storename || '';
    } else {
      this.storeButtonLabel = this.storeIds.length.toString();
      this.selectedVars.var1 = this.storeIds.join(',');
    }
  }
  individualStores(store: any) {
    this.onStoreToggle(store.ID);
  }

  frommonth: Date | null = null;
  Dupfrommonth: Date | null = null;

  minFromMonth: Date = new Date(2000, 0, 1);
  maxFromMonth: Date = new Date();

  monthPickerConfig: Partial<BsDatepickerConfig> = {
    dateInputFormat: 'MMMM YYYY',
    minMode: 'month' as 'month',
    showWeekNumbers: false,
    minDate: this.minFromMonth,
    maxDate: this.maxFromMonth
  };
  changeDatefrom(e: Date | null) {
    this.activePopover = -1;
    if (!e) return;

    this.frommonth = e;
    
    const year = e.getFullYear();
    const month = e.getMonth();
    this.fromDate = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    this.toprevious = e;
    this.minToMonth = e;
    if (this.tomonth && this.tomonth < e) {
      this.tomonth = lastDay;
    }
  }


 
searchTerm: string = '';
isMapped: boolean | null = null;
filteredTableData: any[] = [];
 tableData: any[] = [];
  selectedCategory: string = 'Sale';
apiUrl = 'https://fbxtractapi.axelautomotive.com/api/fredbeans/GetGLAccountsInfo';

// ✅ when pressing Enter in search bar
onSearchEnter() {
  this.getGLAccountsInfo(this.searchTerm);
}

// ✅ when clicking "Mapped" or "Unmapped"
filterMapped(mapped: boolean) {
  this.isMapped = mapped;
  this.applyFilters();
}

// ✅ core function to fetch API data
getGLAccountsInfo(accountNumber: string = '') {
  const body = {
    map_type: 'M',
    store_Id: '0',
    account_Type: this.mapCategoryToType(this.selectedCategory),
    accountnumber: accountNumber, // ✅ bind search term here
    UserID: 1,
    Date: this.frommonth
      ? this.formatDateForApi(this.frommonth)
      : '10-12-2025'
  };

  console.log('API Request Body:', body);

  this.shared.spinner.show();

  this.http.post(this.apiUrl, body).subscribe({
    next: (response: any) => {
      console.log('API Response:', response);
      this.tableData = response?.response || [];
      this.filteredTableData = [...this.tableData];
      this.applyFilters();
      this.shared.spinner.hide();
    },
    error: (err) => {
      console.error('API Error:', err);
      this.shared.spinner.hide();
    }
  });
}

// ✅ main filtering logic (mapped/unmapped + date)
applyFilters() {
  this.activePopover = -1;
  this.isPopoverOpen = false;

  let data = this.tableData;

  if (this.isMapped !== null) {
    data = data.filter((item: any) => {
      const mapped = !!item.Fin_Summary;
      return this.isMapped ? mapped : !mapped;
    });
  }

  // apply date filter if needed
  if (this.frommonth) {
    const year = this.frommonth.getFullYear();
    const month = this.frommonth.getMonth();
    this.fromDate = new Date(year, month, 1);
  }

  if (this.tomonth) {
    const year = this.tomonth.getFullYear();
    const month = this.tomonth.getMonth();
    this.toDate = new Date(year, month + 1, 0);
  }

  this.filteredTableData = data;
  this.cdr.detectChanges();
}

 
formatDateForApi(date: Date): string {
  const d = new Date(date);
  const month = ('0' + (d.getMonth() + 1)).slice(-2);
  const day = ('0' + d.getDate()).slice(-2);
  const year = d.getFullYear();
  return `${month}-${day}-${year}`;
}
 
  mapCategoryToType(category: string): string {
    switch (category) {
      case 'Sale': return 'S';
      case 'Cost': return 'C';
      case 'Non-Operating Expense': return 'NOE';
      case 'Non-Operating Income': return 'NOI';
      case 'Expense': return 'E';
      case 'Asset': return 'A';
      case 'Liability': return 'L';
      case 'Equity': return 'Q';
      default: return 'S';
    }
  }

  //  When user clicks a category button
  setCategory(category: string) {
    this.selectedCategory = category;
    this.getGLAccountsInfo();
  }
}


